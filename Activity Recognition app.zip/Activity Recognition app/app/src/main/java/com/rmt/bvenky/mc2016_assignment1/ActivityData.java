package com.rmt.bvenky.mc2016_assignment1;

/**
 * Created by bvenk on 3/25/2016.
 */
public class ActivityData {

    public long EventTimeStamp;
    public String SMActivity;
}
