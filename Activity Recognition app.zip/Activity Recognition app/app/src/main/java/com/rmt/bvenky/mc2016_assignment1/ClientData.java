package com.rmt.bvenky.mc2016_assignment1;

/**
 * Created by bvenk on 3/25/2016.
 */
public class ClientData {
    public long StartTime;
    public long EndTime;
    public String Activity;

    public int compareTo(ClientData d1)
    {
        return (int)(d1.StartTime - this.StartTime);
    }
}
