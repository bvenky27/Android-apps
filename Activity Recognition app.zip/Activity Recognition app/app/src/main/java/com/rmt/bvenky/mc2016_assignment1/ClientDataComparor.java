package com.rmt.bvenky.mc2016_assignment1;

import java.util.Comparator;

/**
 * Created by bvenk on 3/25/2016.
 */
public class ClientDataComparor implements Comparator<ClientData>{
    @Override
    public int compare(ClientData lhs, ClientData rhs) {
        return lhs.compareTo(rhs);
    }
}
