package com.rmt.bvenky.mc2016_assignment1;

/**
 * Created by bvenk on 3/25/2016.
 */
public class AccelerometerData {

    private float accX, accY, accZ;

    public AccelerometerData(){
        accX = accY = accZ = 0;
    }

    public AccelerometerData(float accX, float accY, float accZ) {
        this.accZ = accZ;
        this.accY = accY;
        this.accX = accX;
    }

    public float getAccX() {
        return accX;
    }

    public void setAccX(float accX) {
        this.accX = accX;
    }

    public float getAccZ() {
        return accZ;
    }

    public void setAccZ(float accZ) {
        this.accZ = accZ;
    }

    public float getAccY() {
        return accY;
    }

    public void setAccY(float accY) {
        this.accY = accY;
    }
}
