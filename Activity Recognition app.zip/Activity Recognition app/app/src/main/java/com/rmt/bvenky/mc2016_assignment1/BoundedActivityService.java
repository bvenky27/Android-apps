package com.rmt.bvenky.mc2016_assignment1;

import android.app.Service;
import android.content.Intent;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Binder;
import android.os.IBinder;
import android.util.Log;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Timer;
import java.util.TimerTask;

public class BoundedActivityService extends Service implements SensorEventListener {
    public BoundedActivityService() {
    }
    static final String LOG_TAG = "ActivityTracker";

    private final IBinder ibinder_=new MyBinder();

    static ArrayList<ActivityData> aData = new ArrayList<ActivityData>();
    static ArrayList<ClientData> cData = new ArrayList<ClientData>();
    static HashMap<String,String> dups = new HashMap<String, String>();
    ArrayList<AccelerometerData> accData = new ArrayList<AccelerometerData>();
    long lastReadTime;
    long lastUpdate;

    SensorManager sm;
    Sensor accelerometerSensoreter;

    public final int DATA_FREQUENCY = 2*60*1000;

    public void start(){
        Log.i(LOG_TAG, "Started Tracking");
        sm = (SensorManager)getSystemService(SENSOR_SERVICE);
        accelerometerSensoreter = sm.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);
        sm.registerListener(this, accelerometerSensoreter, SensorManager.SENSOR_DELAY_NORMAL);

        Timer timer = new Timer();
        timer.scheduleAtFixedRate(new processDataForActivity(),0,DATA_FREQUENCY);

    }

    public void stop()
    {
        Log.i(LOG_TAG, "Stopped Tracking");
        if(sm!=null){
            sm.unregisterListener(this);
        }
    }

    private List<ActivityData> getListObject(boolean reset){
        synchronized (this)
        {
            if (reset){
                int size = aData.size();
                Log.i(LOG_TAG,"inside list object " + aData.size());
                List<ActivityData> retVal = new ArrayList<ActivityData>(aData);
                Log.i(LOG_TAG,"inside list object " + retVal.size());
                return retVal;
            }
            return aData;
        }
    }

    public ArrayList<ClientData> getActivityCollection(){
        synchronized (cData){
            return cData;
        }
    }


    @Override
    public IBinder onBind(Intent intent) {
        // TODO: Return the communication channel to the service.
        //throw new UnsupportedOperationException("Not yet implemented");
        return ibinder_;
    }

    @Override
    public void onSensorChanged(SensorEvent event) {

        accData.add(new AccelerometerData(event.values[0],event.values[1],event.values[2]));


    }


    @Override
    public void onAccuracyChanged(Sensor sensor, int accuracy) {

    }

    public class MyBinder extends Binder{
        BoundedActivityService getService(){
            return BoundedActivityService.this;
        }
    }

    class processDataForActivity extends TimerTask {

        @Override
        public void run() {
            processRawAccelerometerData();
            processActivityCollection();

        }

        public void processActivityCollection() {

            Log.i(LOG_TAG, "activity list");
            List<ActivityData> tempActivityData = getListObject(true);
            long startTime = 0;
            int counter = 0, sitCount = 0, sleepCount = 0, walkingCount = 0;
            for (ActivityData sData : tempActivityData) {
                counter++;

                if (counter == 1) {
                    startTime = sData.EventTimeStamp;
                }
                if (sData.EventTimeStamp - startTime > DATA_FREQUENCY) {
                    ClientData cd = new ClientData();

                    cd.Activity = maxAcitivity(sleepCount, sitCount, walkingCount);
                    cd.StartTime = startTime;
                    cd.EndTime = sData.EventTimeStamp;
                    if (!dups.containsKey(String.valueOf(startTime + sData.EventTimeStamp))) {
                        cData.add(cd);
                        dups.put(String.valueOf(startTime + sData.EventTimeStamp), "1");
                    }

                    startTime = sData.EventTimeStamp;
                    sitCount = 0;
                    sleepCount = 0;
                    counter = 0;
                } else {
                    if (sData.SMActivity == "sitting")
                        sitCount++;
                    else if (sData.SMActivity == "sleeping")
                        sleepCount++;
                    else
                        walkingCount++;
                }

            }

        }

        public void processRawAccelerometerData() {

            sm.unregisterListener(BoundedActivityService.this);
            List<AccelerometerData> sensorData = new ArrayList<>(accData);
            accData.clear();
            sm.registerListener(BoundedActivityService.this, accelerometerSensoreter, SensorManager.SENSOR_DELAY_NORMAL);
            for (Iterator<AccelerometerData> it = sensorData.iterator(); it.hasNext(); ) {
                AccelerometerData tempAccData = it.next();
                String action = "";

                if (isWalking(tempAccData)) action = "walking";
                else if (isSitting(tempAccData)) action = "sitting";
                else action = "sleeping";

                //Log.i(LOG_TAG, "SensorManager_Update: " + action);
                long curTime = System.currentTimeMillis();
                ActivityData temp = new ActivityData();
                temp.SMActivity = action;
                temp.EventTimeStamp = curTime;
                getListObject(false).add(temp);
            }
        }

        private boolean isWalking(AccelerometerData accelerometerData) {

            Float[] accelerometer_values = {accelerometerData.getAccX(), accelerometerData.getAccY(), accelerometerData.getAccZ()};
            double[] gravity = new double[3];

            //split gravity between all axis based on tilt.
            final double GRAVITY_CONSTANT = 9.8d;
            double normalization = Math.sqrt(accelerometer_values[0] * accelerometer_values[0] + accelerometer_values[1] * accelerometer_values[1] + accelerometer_values[2] * accelerometer_values[2]);
            gravity[0] = accelerometer_values[0] * GRAVITY_CONSTANT / normalization;
            gravity[1] = accelerometer_values[1] * GRAVITY_CONSTANT / normalization;
            gravity[2] = accelerometer_values[2] * GRAVITY_CONSTANT / normalization;

            double[] linear_acceleration = new double[3];

            linear_acceleration[0] = (accelerometer_values[0] - gravity[0]);
            linear_acceleration[1] = (accelerometer_values[1] - gravity[1]);
            linear_acceleration[2] = (accelerometer_values[2] - gravity[2]);

            float magnitude = 0.0f;
            magnitude = (float) Math.sqrt(linear_acceleration[0] * linear_acceleration[0] + linear_acceleration[1] * linear_acceleration[1] + linear_acceleration[2] * linear_acceleration[2]);
            magnitude = Math.abs(magnitude);
            if (magnitude > 0.5) {
                return true;
            }
            return false;
        }

        private boolean isSitting(AccelerometerData accelerometerData) {
            if (Math.abs(accelerometerData.getAccY()) > Math.max(Math.abs(accelerometerData.getAccX()), Math.abs(accelerometerData.getAccZ()))) {
                return true;
            }
            return false;
        }
    }

    public String maxAcitivity(int sleepCount, int sitCount, int walkCount){
        return sleepCount > sitCount ? (sleepCount > walkCount ? "sleeping":"walking" ) : (sitCount > walkCount ? "sitting" : "walking");
    }
}
