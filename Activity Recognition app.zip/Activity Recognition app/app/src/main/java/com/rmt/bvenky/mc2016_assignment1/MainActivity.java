package com.rmt.bvenky.mc2016_assignment1;

import android.app.Activity;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.os.Bundle;
import android.os.Environment;
import android.os.IBinder;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.Display;
import android.view.View;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Button;
import android.widget.TextView;
import android.os.Handler;
import android.widget.Toast;

import java.io.FileOutputStream;
import java.io.PrintWriter;
import java.text.Format;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.List;
//import java.util.logging.Handler;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    BoundedActivityService myService;
    boolean connected = false;
    TextView activityShow;
    Button start, stop, show;
    PrintWriter captureFile;
    long lastUpdate = 0;

    public final int DATA_FREQUENCY = 2*60*1000;

    private Handler mHandler = new Handler();
    private ServiceConnection mConnection = new ServiceConnection() {
        @Override
        public void onServiceConnected(ComponentName name, IBinder service) {
            Log.i("Activity", "Service Connected");
            BoundedActivityService.MyBinder binder = (BoundedActivityService.MyBinder) service;
            myService=binder.getService();
            connected=true;

        }

        @Override
        public void onServiceDisconnected(ComponentName name) {
            myService=null;
            connected=false;
            Log.i("Activity", "Service Disconnected");

        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        Intent myIntent = new Intent(this, BoundedActivityService.class);
        bindService(myIntent, mConnection, Context.BIND_AUTO_CREATE);

        FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
                        .setAction("Action", null).show();
            }
        });

        activityShow=(TextView) findViewById(R.id.textViewActivity);
        activityShow.setText("");
        start = (Button) findViewById(R.id.buttonStart);
        stop = (Button) findViewById(R.id.buttonStop);
        show =(Button) findViewById(R.id.buttonShow);
        start.setOnClickListener(this);
        stop.setOnClickListener(this);
        show.setOnClickListener(this);
        mHandler.postDelayed(r, DATA_FREQUENCY);


    }

    final Runnable r = new Runnable() {
        @Override
        public void run() {
            Log.i("ActivityTracker", "inside polling: ");
            if(myService !=null)
            {
                ArrayList<ClientData> data = myService.getActivityCollection();
                if (data!=null)
                {
                    Displays(data, true);

                }

            }

            mHandler.postDelayed(this,DATA_FREQUENCY);



        }
    };

    private String convertTime(long time){

        Date date = new Date(time);
        Format format = new SimpleDateFormat("HH:mm");
        return format.format(date);

    }

    private void Displays(ArrayList<ClientData> data, boolean writeToFile)
    {
        Log.i("ActivityTracker","Inside Display");
        if (data.size() == 0)
        {
            activityShow.setText("");
            return;
        }
        Collections.sort(data, new ClientDataComparor());
        int counter = 0;
        StringBuilder sb = new StringBuilder("");
        for(ClientData d : data) {
            counter++;
            if (!writeToFile)
            {
                Log.i("replace check: ",sb.toString());
                if (counter > 10){
                    String replace = sb.substring(sb.indexOf("\n")+2);
                    sb.replace(0,sb.length(),replace);
                    Log.i("replace check: ",replace);
                }
                String temp = "\n"
                        + convertTime(d.StartTime) + " - "
                        + convertTime(d.EndTime) + " "
                        + d.Activity.toUpperCase();
                sb.append(temp);
            }
            else
            {
                String temp = "\n"
                        + convertTime(d.StartTime) + " - "
                        + convertTime(d.EndTime) + " "
                        + d.Activity.toUpperCase();
                sb.append(temp);
            }
        }

        activityShow.setText(sb.toString());
        if (writeToFile)
            Writetofile(sb.toString());

    }
    public void Writetofile(String text){
        try {
            //String Path = Environment.getExternalStorageDirectory().getPath() + "/ActivityTracker.txt";
            String Path = "/sdcard/ActivityTracker.txt";
            Log.i("data",text);
            FileOutputStream overWrite = new FileOutputStream(Path, false);
            overWrite.write(text.getBytes());
            overWrite.flush();
            overWrite.close();

            Toast.makeText(getApplicationContext(), "File saved successfully",
                    Toast.LENGTH_SHORT).show();
        }catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    @Override
    public void onClick(View v) {

        switch (v.getId())
        {
            case R.id.buttonStart:
                myService.start();
                break;
            case R.id.buttonStop:
                myService.stop();
                break;
            case R.id.buttonShow:
                Displays(myService.getActivityCollection(), false);
                break;
        }

    }

    @Override
    protected void onStop() {
        super.onStop();
        Log.i("Activity", "connected = " + connected);
        if (connected)
            unbindService(mConnection);
        if (captureFile!=null){
            captureFile.close();
            captureFile=null;
        }

    }
}
