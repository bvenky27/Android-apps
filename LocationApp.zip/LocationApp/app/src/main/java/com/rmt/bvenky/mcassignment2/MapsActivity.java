package com.rmt.bvenky.mcassignment2;

import android.Manifest;
import android.content.Context;
import android.content.pm.PackageManager;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.AsyncTask;
import android.support.v4.app.ActivityCompat;
import android.support.v4.app.FragmentActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;


import com.google.android.gms.drive.internal.StringListResponse;

import com.google.android.gms.maps.CameraUpdate;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.List;

public class MapsActivity extends FragmentActivity implements OnMapReadyCallback, View.OnClickListener, LocationListener {

    private GoogleMap mMap;
    private EditText locationInput; //for getting location input
    private Button locButton; //for submitting the input
    private String input; // storing the input
    private Context context;
    private final String SERVER_KEY = "AIzaSyCt0BvmxK7PtDbjrFB41FXb-Ltkym9Tvsc"; //required for connecting to the google places api
    private LocationManager locationManager;
    private TextView showPresentSearch, distance; //to display the specified location
    private Location currentLocation; //to store the current location
    private QueryResult destination = null; //to store the longitude and latitude of the specified location
    private final float MIN_DISTANCE = 1;
    private final long MIN_TIME = 10000;
    //Marker marker;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_maps);
        // Obtain the SupportMapFragment and get notified when the map is ready to be used.
        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.map);
        mapFragment.getMapAsync(this);

        context = this;


        //starting the location service
        locationManager = (LocationManager) getSystemService(LOCATION_SERVICE);
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            // TODO: Consider calling
            //    ActivityCompat#requestPermissions
            // here to request the missing permissions, and then overriding
            //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
            //                                          int[] grantResults)
            // to handle the case where the user grants the permission. See the documentation
            // for ActivityCompat#requestPermissions for more details.
            return;
        }
        //to get the current location
        currentLocation = locationManager.getLastKnownLocation(LocationManager.NETWORK_PROVIDER);

        locButton = (Button) findViewById(R.id.buttonloc);
        locationInput = (EditText) findViewById(R.id.editText);
        locButton.setOnClickListener(this);
        showPresentSearch = (TextView) findViewById(R.id.textView2);
        distance = (TextView) findViewById(R.id.textviewDistance);


    }


    @Override
    protected void onStart() {

        super.onStart();
    }

    @Override
    protected void onStop() {

        super.onStop();
    }

    @Override
    protected void onResume() {

        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            // TODO: Consider calling
            //    ActivityCompat#requestPermissions
            // here to request the missing permissions, and then overriding
            //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
            //                                          int[] grantResults)
            // to handle the case where the user grants the permission. See the documentation
            // for ActivityCompat#requestPermissions for more details.
            return;
        }

        // here we are requesting location update for every 10 secs or if there is a change of 1 meter from previous location
        locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, MIN_TIME, MIN_DISTANCE, this);


        super.onResume();
    }

    @Override
    protected void onPause() {
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            // TODO: Consider calling
            //    ActivityCompat#requestPermissions
            // here to request the missing permissions, and then overriding
            //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
            //                                          int[] grantResults)
            // to handle the case where the user grants the permission. See the documentation
            // for ActivityCompat#requestPermissions for more details.
            return;
        }
        //releasing the location resource when the app is in pause state
        locationManager.removeUpdates(this);
        super.onPause();
    }

    /**
     * Manipulates the map once available.
     * This callback is triggered when the map is ready to be used.
     * This is where we can add markers or lines, add listeners or move the camera. In this case,
     * we just add a marker near Sydney, Australia.
     * If Google Play services is not installed on the device, the user will be prompted to install
     * it inside the SupportMapFragment. This method will only be triggered once the user has
     * installed Google Play services and returned to the app.
     */
    @Override
    public void onMapReady(GoogleMap googleMap) {
        mMap = googleMap;

        // Add a marker in Sydney and move the camera
        //LatLng sydney = new LatLng(0, 0);
        //mMap.addMarker(new MarkerOptions().position(sydney).title("Marker in Sydney"));
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            // TODO: Consider calling
            //    ActivityCompat#requestPermissions
            // here to request the missing permissions, and then overriding
            //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
            //                                          int[] grantResults)
            // to handle the case where the user grants the permission. See the documentation
            // for ActivityCompat#requestPermissions for more details.
            return;
        }
        //to mark the current location
        mMap.setMyLocationEnabled(true); // to mark the current location
        //mMap.moveCamera(CameraUpdateFactory.newLatLng(sydney));
        /*LatLng curr = new LatLng(currentLocation.getLatitude(),currentLocation.getLatitude());
        mMap.moveCamera(CameraUpdateFactory.newLatLng(curr));
        mMap.animateCamera(CameraUpdateFactory.zoomTo(15));*/
    }


    @Override
    public void onClick(View v) {

        if (v.getId() == R.id.buttonloc) {
            //storing the specified location in input
            input = locationInput.getText().toString();
            showPresentSearch.setText("Searched Location: " + input);
            //calling async task for getting the geolocation of the specified place with current location parameters
            new GoogleApp().execute(currentLocation.getLatitude(), currentLocation.getLongitude());

        }

    }

    private boolean isInRange() {

        Location search = new Location("");
        search.setLatitude(destination.getLatitude());
        search.setLongitude(destination.getLongitude());
        float distance_ = currentLocation.distanceTo(search);
        Log.d("distance: ", String.valueOf(distance_));
        //checks if the distance is less than 200
        return distance_ < 200;

    }

    @Override
    public void onLocationChanged(Location location) {


                if (location != null) {
                    currentLocation.setLatitude(location.getLatitude());
                    currentLocation.setLongitude(location.getLongitude());
                    mMap.clear();
                    if (destination != null) {
                        Location search = new Location("");
                        search.setLatitude(destination.getLatitude());
                        search.setLongitude(destination.getLongitude());
                        //calculating the distance and displaying in textview
                        String distancedisplay = "Distance from the current location: "+ String.valueOf(search.distanceTo(location))+"mts";

                        distance.setText(distancedisplay);
                        //marking the specified location

                        QueryResult data = destination;
                        LatLng destination_ = new LatLng(data.getLatitude(), data.getLongitude());
                        mMap.addMarker(new MarkerOptions().position(destination_).title(data.getName()).icon(BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_BLUE)));
                        CameraUpdate centre = CameraUpdateFactory.newLatLng(destination_);
                        CameraUpdate zoom = CameraUpdateFactory.zoomTo(14);
                        mMap.moveCamera(centre);
                        mMap.animateCamera(zoom);


                        //checks if it is in 200 mts range or not
                        if (isInRange()) {
                            Toast.makeText(context, "You are with in 200 mts from the desired location", Toast.LENGTH_LONG).show();
                        }
                    }

                }
            }




    @Override
    public void onStatusChanged(String provider, int status, Bundle extras) {

    }

    @Override
    public void onProviderEnabled(String provider) {

    }

    @Override
    public void onProviderDisabled(String provider) {

    }


    private class GoogleApp extends AsyncTask<Double, Void, Boolean>{

        @Override
        protected Boolean doInBackground(Double... params) {
            boolean result = false;
            destination = new QueryResult();

            if(input != null || input.equals("")){
                Log.d("input", input);
                Log.d("currentloaction", params[0]+","+params[1]);
                String urlstring = "https://maps.googleapis.com/maps/api/place/nearbysearch/json?"+
                        "location="+params[0]+","+params[1]+
                        "&rankby=distance&name="+input+
                        "&key="+SERVER_KEY;
                urlstring = urlstring.replace(" ","+");
                Log.d("url", urlstring);
                HttpURLConnection con = null;
                String resultString= null;
                //requesting the location of specified place through http request
                try{
                    URL url = new URL(urlstring);
                    con = (HttpURLConnection) url.openConnection();
                    StringBuffer sb = new StringBuffer();
                    InputStream inputStream = new BufferedInputStream(con.getInputStream());
                    BufferedReader br = new BufferedReader(new InputStreamReader(inputStream));
                    String lineinput = "";
                    while ((lineinput = br.readLine())!= null){
                        sb.append(lineinput);
                    }

                    resultString= sb.toString();
                    //the response is stored as json array
                    JSONArray jsonArray = new JSONObject(resultString).getJSONArray("results");
                    int count = jsonArray.length();
                    Log.d("INFO", String.valueOf(count));

                    if(count > 0){
                        result = true;
                    }

                    //of all the list of results, first suggestion is taken as preference and stored as json object

                    JSONObject firstobject = jsonArray.getJSONObject(0);

                    JSONObject loc = firstobject.getJSONObject("geometry").getJSONObject("location");
                    QueryResult queryResult = new QueryResult();
                    queryResult.setLatitude(loc.getDouble("lat"));
                    queryResult.setLongitude(loc.getDouble("lng"));
                    queryResult.setName(input.toUpperCase());
                    Log.d("Name", queryResult.getName()+","+queryResult.getLatitude()+","+queryResult.getLongitude());
                    synchronized (MapsActivity.this){
                        destination = queryResult;
                    }




                } catch (Exception e){

                    Log.d("Exception at Json: ",e.getMessage());

                }
            }

            return result;

        }

        //on getting the geolocation, marking that location is done in onPostExecute and again calculating distance
        //for the first time to check whether the specified location is in 200 mts or not

        @Override
        protected void onPostExecute(Boolean aBoolean) {
            super.onPostExecute(aBoolean);

            if (aBoolean){
                mMap.clear();
                QueryResult data = destination;
                LatLng destination_ = new LatLng(data.getLatitude(), data.getLongitude());
                mMap.addMarker(new MarkerOptions().position(destination_).title(data.getName()).icon(BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_BLUE)));
                CameraUpdate centre = CameraUpdateFactory.newLatLng(destination_);
                CameraUpdate zoom = CameraUpdateFactory.zoomTo(14);
                mMap.moveCamera(centre);
                mMap.animateCamera(zoom);

                Location search = new Location("");
                search.setLatitude(destination.getLatitude());
                search.setLongitude(destination.getLongitude());
                String distancedisplay = "Distance from the current location: "+ String.valueOf(search.distanceTo(currentLocation))+"mts";

                distance.setText(distancedisplay);

                if (isInRange()) {
                    Toast.makeText(context, "You are with in 200 mts from the desired location", Toast.LENGTH_LONG).show();
                }


            }
        }
    }
}
