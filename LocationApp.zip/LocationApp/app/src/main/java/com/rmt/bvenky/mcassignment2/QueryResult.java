package com.rmt.bvenky.mcassignment2;

import java.io.Serializable;

/**
 * Created by bvenk on 4/27/2016.
 */
public class QueryResult implements Serializable{

    //for storing the results

    private String name;
    private double latitude;
    private double longitude;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public double getLatitude() {
        return latitude;
    }

    public void setLatitude(double latitude) {
        this.latitude = latitude;
    }

    public double getLongitude() {
        return longitude;
    }

    public void setLongitude(double longitude) {
        this.longitude = longitude;
    }



}
